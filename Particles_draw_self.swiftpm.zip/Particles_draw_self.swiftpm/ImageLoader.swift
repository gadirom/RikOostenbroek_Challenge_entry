
import Foundation
import Combine
import SwiftUI

class ImageLoader {
    
    var images: [UIImage] = []
    
    private func loadPublisher(url: URL) ->AnyCancellable{
        URLSession.shared.dataTaskPublisher(for: url)
            .map { UIImage(data: $0.data) }
            .sink(receiveCompletion:
                    { print($0) },
                  receiveValue:
                    { self.images.append($0!) })
    }
    func load(urls: [URL]) {
        
        let cancallables = urls.map{ loadPublisher(url: $0)}
        
        while images.count<urls.count {}
    }
}
