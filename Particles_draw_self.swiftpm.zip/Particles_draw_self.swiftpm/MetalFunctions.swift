let metalFunctions = """

struct VertexOut{
    float4 position [[position]];
    float size [[point_size]];
    float4 color; 
};

vertex VertexOut
vertexShader(uint id [[vertex_id]]){
  VertexOut out;
  Particle p = particles[id];
  out.position = float4(p.coord.xy, 0, 1);
  out.size = p.size*float(viewportSize.x)*0.1*u.size;

  constexpr sampler s(address::clamp_to_edge, filter::linear);
  float2 uv = p.coord.xy*float2(1,-1)*.5+.5;
  int breed = int(p.breed);
  float d = mix(1, 1.-sdf.sample(s, uv, breed).r, u.mask);
  out.color = p.color*(0.01+length(p.coord.xy-p.coord.zw))*d;
  return out;
}
fragment float4 fragmentShader(VertexOut in [[stage_in]],
                               float2 p [[point_coord]]){
    if(length(p-.5)>0.5) discard_fragment();
    return in.color;
}
kernel void integration(uint id [[thread_position_in_grid]]){
   //Integration
   Particle p = particles[id];
   float2 velo = p.coord.xy-p.coord.zw;
   p.coord.zw = p.coord.xy;
   
   constexpr sampler s(address::clamp_to_edge, filter::linear);
   float2 e = float2(0.001, 0.);

   float2 uv = p.coord.xy*float2(1,-1)*.5+.5;
   int breed = int(p.breed);
   float d = sdf.sample(s, uv, breed).r;
   float d1 = sdf.sample(s, uv-e.xy, breed).r;
   float d2 = sdf.sample(s, uv-e.yx, breed).r;
   float2 n = d - float2(d1, d2);
   n = length(n)==0 ? float2(0) : normalize(n);
   n *= sign(d) * pow(abs(d), 2.);
   //float2 sdfForce = n*(d);
   
   float2 force = n*u.gravity*100+p.force;//+sdfForce;

   velo += force/(1+velo*velo);
   //velo *= -1*(ceil(max(0., abs(p.coord.xy)-1.))*2-1);
   p.coord.xy += velo*0.9;

   //Edge constraint
   if (p.coord.x>1) p.coord.x=1;
   if (p.coord.x<-1) p.coord.x=-1;
   if (p.coord.y>1) p.coord.y=1;
   if (p.coord.y<-1) p.coord.y=-1;

   particles[id] = p;
}

kernel void collision(uint id [[thread_position_in_grid]],
                      uint count [[threads_per_grid]]){
  Particle p = particlesIn[id];
  float2 fgrav = 0;
  //float2 frep = 0;
  for(uint id1=0; id1<count; id1++){
      if (id==id1) continue;
      Particle p1 = particlesIn[id1];
      float2 axis = p1.coord.xy - p.coord.xy;
      float dist = length(axis);
       if (dist == 0) continue;
      float size = p.size+p1.size;
      float2 n = axis/dist;
      if (u.blob==1){
      if (p.breed == p1.breed){
         fgrav += n/(dist*dist)*u.gravity*size;
      }else{
         fgrav -= n/(dist*dist)*u.gravity*size;
      }
      }else{
         fgrav += n/(dist*dist)*u.gravity*size;
      }
      if (dist<size){
        float shift = min(size-dist, 0.05);
        p.coord.xy -= (p.size/size)*shift*n*u.fric;
        //p1.coord.xy -= 0.5*shift*n;
        //particlesIn[id1] = p1;
      }
   }
   float2 dir = p.coord.xy - p.coord.zw;
   float dist = length(dir);
   if (dist>0){
      float2 n = dir/dist;
      dist = min(dist, 0.01);
      p.coord.xy = p.coord.zw + n*dist;
   }
   p.force = fgrav;
   particlesOut[id] = p;
}

kernel void threshold(uint2 gid [[thread_position_in_grid]]){
     float d = sdf.read(gid, 1).r;
     float3 in = blur.read(gid).rgb;
     float3 hue = normalize(in);
     float light = smoothstep(u.threshold, u.threshold+0.05, length(in));
     float3 color = pow(hue*light*(u.brightness), 1.);

     float3 prevCol = prev.read(gid).rgb-u.dim;
     color = max(color, prevCol);
     out.write(float4(color, 1), gid);
     //out.write(float4(d*.001), gid);
}
"""
