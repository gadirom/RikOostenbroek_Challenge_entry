
import MetalBuilder
import MetalKit
import MetalPerformanceShaders
import SwiftUI

public enum ScaleMethod {
        case nearestNeighbor //- not implemented!
        case lanczos
        case bilinear
    }

struct LoadSDF: MetalBuildingBlock{
    var context: MetalBuilderRenderingContext
    var helpers = ""
    var librarySource = loadSDFSource
    var compileOptions: MetalBuilderCompileOptions? = nil
    
    @MetalTexture(texDesc) var imageTexture
    @MetalTexture(texDesc
        .pixelFormat(.r16Float)) var grayTexture
    @MetalTexture(texDesc
        .pixelFormat(.r16Float)) var inverseTexture
    @MetalTexture(texDesc
        .pixelFormat(.r16Float)) var straightSDFTexture
    @MetalTexture(texDesc
        .pixelFormat(.r16Float)) var inverseSDFTexture
    @MetalTexture(texDesc
        .pixelFormat(.r16Float)) var sdfTexture
    
    @MetalState var i = 0
    
    var sdfTextureArray: MTLTextureContainer
    var urls: [URL]
    
    @MetalState var radius: Float = 0
    
    var metalContent: MetalContent{
        EncodeGroup{
            ManualEncode{device,commandBuffer,_  in
                print("Loading texture")
                let imageLoader = ImageLoader()
                let url = urls[$i.wrappedValue]
                imageLoader.load(urls: [url])
                
                let image = imageLoader.images.first!
                            
                let textureLoader = MTKTextureLoader(device: device)
                
                let options: [MTKTextureLoader.Option:Any] = [
                    MTKTextureLoader.Option.textureUsage: NSNumber(value: MTLTextureUsage.shaderRead.rawValue | MTLTextureUsage.shaderWrite.rawValue | MTLTextureUsage.renderTarget.rawValue),
                    MTKTextureLoader.Option.SRGB: false
                ]
                let texture: MTLTexture?
                do{
                    texture = try textureLoader.newTexture(cgImage: image.cgImage!, options: options)
                
                    let width = Double(texture!.width)
                    let height = Double(texture!.height)
                      
                    let vpWidth = Double(context.viewportSize.x)
                    let vpHeight = Double(context.viewportSize.y)
                    
                    let zooming: Double = min(vpWidth/width,
                                              vpHeight/height)*0.9
                    let scaleX: Double = zooming
                    let scaleY: Double = zooming
                    let translateX: Double = (vpWidth-zooming*width)/2
                    let translateY: Double = (vpHeight-zooming*height)/2
                    
                    var scaleTransform = MPSScaleTransform(scaleX: scaleX,
                                                           scaleY: scaleY,
                                                           translateX: translateX,
                                                           translateY: translateY)
                    var scl: MPSImageScale
                    
                    let scaleMethod = ScaleMethod.lanczos
                    
                    // choose Scaling Method
                    switch scaleMethod {
                    case .lanczos:
                        scl = MPSImageLanczosScale(device: device)
                        
                    case .bilinear:
                        scl = MPSImageBilinearScale(device: device)
                        
                    case .nearestNeighbor:  // not implemented!!
                        scl = MPSImageBilinearScale(device: device)
                    }
                    
                    withUnsafePointer(to: &scaleTransform) { (transformPtr: UnsafePointer<MPSScaleTransform>) -> () in
                        scl.scaleTransform = transformPtr
                    }
                    
                    scl.encode(commandBuffer: commandBuffer,
                               sourceTexture: texture!,
                               destinationTexture: imageTexture.texture!)
                        
                }catch{
                    print(error)
                }
            }
            Compute("convert")
                .texture(imageTexture, argument: .init(type: "float", access: "read", name: "sdf"),
                fitThreads: true)
                .texture(grayTexture, argument: .init(type: "float", access: "write", name: "out"))
            MPSUnary{
                MPSImageThresholdBinaryInverse(device: $0,
                                               thresholdValue: 0.5,
                                               maximumValue: 1,
                                               linearGrayColorTransform: nil)
            }
            .source(grayTexture)
            .destination(inverseTexture)
            MPSUnary{
                //MPSImageGaussianBlur(device: $0,
                 //                    sigma: autoUniforms.getFloat("blur")!)
                radius = 500
                return MPSImageEuclideanDistanceTransform(device: $0)
            }
            .value($radius.binding, for: "searchLimitRadius")
            .source(grayTexture)
            .destination(straightSDFTexture)
            MPSUnary{
                //MPSImageGaussianBlur(device: $0,
                 //                    sigma: autoUniforms.getFloat("blur")!)
                radius = 500
                return MPSImageEuclideanDistanceTransform(device: $0)
            }
            .value($radius.binding, for: "searchLimitRadius")
            .source(inverseTexture)
            .destination(inverseSDFTexture)
            Compute("mergeSDF")
                .texture(straightSDFTexture, argument: .init(type: "float", access: "read", name: "straight"),
                fitThreads: true)
                .texture(inverseSDFTexture, argument: .init(type: "float", access: "read", name: "inverse"))
                .texture(sdfTexture, argument: .init(type: "float", access: "write", name: "out"))
            BlitTexture()
                .source(sdfTexture)
                .destination(sdfTextureArray, slice: $i.binding)
            CPUCompute{_ in
                i+=1
            }
        }.repeating(urls.count)
        CPUCompute{_ in
            imageTexture.texture = nil
            grayTexture.texture = nil
            inverseTexture.texture = nil
            straightSDFTexture.texture = nil
            inverseSDFTexture.texture = nil
            i=0
        }
    }
}

let loadSDFSource = """
kernel void convert(uint2 gid [[thread_position_in_grid]]){
    float d = sdf.read(gid).a;
    out.write(float4(d), gid);
}
kernel void mergeSDF(uint2 gid [[thread_position_in_grid]]){
    float d = straight.read(gid).r;
    //d += inverse.read(gid).r;
    out.write(float4(d), gid);
}
"""
