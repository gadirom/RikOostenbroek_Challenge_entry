//Created by Roman Gaditskii https://twitter.com/gadirom_
//for the challenge of Rik Oostenbroek
//2022(c)

import SwiftUI
import MetalBuilder
import MetalKit
import MetalPerformanceShaders

let urls = ["Sketch_skin",
            "Sketch_browns",
            "Sketch_darks",
            "Sketch_orange",
            "Sketch_blues"].map{ Bundle.main.url(forResource: $0, withExtension: "png")! }

struct Particle: MetalStruct{
    var coord: simd_float4 = [0,0,0,0]
    var size: Float = 0
    var color: simd_float4 = [0,0,0,0]
    var force: simd_float2 = [0,0]
    var breed: Float = 0
}
let uniforms = UniformsContainer(UniformsDescriptor()
    .float("gravity", range: -0.1...0.1, value: 0.0)
    .float("fric", value: 0.05)
    .float("threshold", range: 0...1, value: 0)
    .float("mask", range: 0...1, value: 0)
    .float("sigma", range: 0...50, value: 0)
    .float("brightness", range: 0...50, value: 1)
    .float("dim", range: 0...0.5, value: 0.01)
    .float("size", range: 0...10, value: 1)
    .float("pressure", range: 0...50, value: 25)
    .float("blob", value: 0),
                                 name: "u"
)

let particlesCount = 3000//increase if you have a powerful device!

let texDesc = TextureDescriptor()
    .type(.type2D)
    .pixelFormatFromDrawable()
    //.pixelFormat(.rgba16Float)
    .usage([.renderTarget, .shaderRead, .shaderWrite])
    .sizeFromViewport(scaled: 1)

let texArrayDesc = TextureDescriptor()
    .type(.type2DArray)
    .arrayLength(urls.count)
    
    //.pixelFormatFromDrawable()
    .pixelFormat(.r16Float)
    .usage([.shaderRead, .shaderWrite])
    //.sizeFromViewport(scaled: 1)

let bufDescriptor = BufferDescriptor()
    .metalName("particles")
    .count(particlesCount)

struct ContentView: View {
    
    @MetalTexture(texDesc
                  //.pixelFormat(.rgba16Float)
    ) var blurTexture
    @MetalTexture(texDesc) var targetTexture
    @MetalTexture(texDesc) var drawTexture
    
    @MetalTexture(texArrayDesc) var sdfTextures
    
    @MetalBuffer<Particle>(bufDescriptor) var particlesBuffer
    @MetalBuffer<Particle>(bufDescriptor) var particlesBuffer1
    
    @State var isDrawing = false
    
    @MetalState var lastTime: Double = 0
    @MetalState var particleId = 0
    
    @MetalState var loadSDF = 1
    
    let colors: [Color] = [.red, .yellow, .green, .purple, .blue]
    @State var breed = 0
    @MetalState var color: simd_float4 = simd_float4([1, 0, 0, 1])
    
    @State var blob = false
    @State var play = 0
    @State var fps: Double = 0

    @MetalState var dragging = false
    @MetalState var coord: simd_float2 = [0, 0]
    @State var save = 0
    @State var load = 0
    @MetalState var data = Data()
    @MetalState var bufData = Data()
    var body: some View {
        VStack {
            //Text("\(fps)")
            MetalBuilderView(librarySource: metalFunctions,
                             isDrawing: $isDrawing) { context in
                ManualEncode{_, _, _ in
                    let lastTime = $lastTime.wrappedValue
                    let time = CFAbsoluteTimeGetCurrent()
                    $lastTime.wrappedValue = time
                    fps = fps*0.99+0.01/(time-lastTime)
                    if $dragging.wrappedValue{
                        for _ in 0..<Int(uniforms.getFloat("pressure")!){
                            let size = context.viewportSize
                            let coord = (context.scaleFactor*2*coord/simd_float2(size)-1)*simd_float2(1, -1)
                            let velo = simd_float2.random(in: 0...0.0)
                            particlesBuffer.pointer![$particleId.wrappedValue].coord = [coord.x, coord.y, coord.x-velo.x, coord.y-velo.y]
                            particlesBuffer.pointer![$particleId.wrappedValue].size = Float.random(in: 0.01...0.05)
                            particlesBuffer.pointer![$particleId.wrappedValue].color = color
                            particlesBuffer.pointer![$particleId.wrappedValue].breed = Float(breed)
                            particleId += 1
                            if particleId >= particlesCount{particleId = 0}
                        }
                    }
                }
                EncodeGroup{//load SDF
                    LoadSDF(context: context,
                            sdfTextureArray: sdfTextures, urls: urls)
                    ManualEncode{_,_,_ in
                        loadSDF = 0
                        play = 1
                    }
                }.repeating($loadSDF)
                EncodeGroup{
                    Compute("integration")
                        .texture(sdfTextures, argument: .init(type: "float", access: "sample", name: "sdf"))
                        .buffer(particlesBuffer, space: "device", fitThreads: true)
                        .uniforms(uniforms)
                    EncodeGroup{
                        Compute("collision")
                            .buffer(particlesBuffer, name: "particlesIn", fitThreads: true)
                            .buffer(particlesBuffer1, space: "device", name: "particlesOut")
                            .uniforms(uniforms)
                        Compute("collision")
                            .buffer(particlesBuffer1, name: "particlesOut", fitThreads: true)
                            .buffer(particlesBuffer, space: "device", name: "particlesIn")
                            .uniforms(uniforms)
                    }.repeating(2)
                Render(vertex: "vertexShader", fragment: "fragmentShader", type: .point, count: particlesCount)
                    .toTexture(blurTexture)
                    .vertexBuf(particlesBuffer)
                    .uniforms(uniforms)
                    .vertexBytes(context.$viewportSize)
                    .vertexTexture(sdfTextures,
                                 argument: .init(type: "float", access: "sample", name: "sdf"))
                    
                MPSUnary { device in
                    MPSImageGaussianBlur(device: device, sigma: uniforms.getFloat("sigma")!)
                }
                .source(blurTexture)
                Compute("threshold")
                    .texture(sdfTextures,
                                 argument: .init(type: "float", access: "read", name: "sdf"))
                    .texture(blurTexture,
                             argument: .init(type: "float", access: "read", name: "blur"))
                    .texture(targetTexture,
                             argument: .init(type: "float", access: "read", name: "prev"))
                    .texture(drawTexture,
                             argument: .init(type: "float", access: "write", name: "out"))
                    .uniforms(uniforms)
                BlitTexture()
                    .source(drawTexture)
                    .destination(targetTexture)
                }.repeating($play)
                EncodeGroup{
                    CPUCompute{ device in
                        print("save")
                        data = targetTexture.getData(type: SIMD4<UInt8>.self)
                        //saveTexture(device: device)
                        bufData = particlesBuffer.getData()
                        save = 0
                        //play = 1
                    }
                }.repeating($save)
                EncodeGroup{
                    CPUCompute{ device in
                        print("load")
                        targetTexture.load(data: data, type: SIMD4<UInt8>.self)
                        drawTexture.load(data: data, type: SIMD4<UInt8>.self)
                        //loadTexture(device: device)
                        particlesBuffer.load(data: bufData)
                        print("loaded")
                        load = 0
                        //play = 1
                    }
                }.repeating($load)
                BlitTexture()
                    .source(drawTexture)
            }.onResize { size in
                createParticles(particlesBuffer)
                isDrawing = true
                loadSDF = 1
            }
            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
                .onChanged{ value in
                    coord = [Float(value.location.x),
                             Float(value.location.y)]
                    //print(coord)
                    dragging = true
                }
                .onEnded{_ in
                    dragging = false
                })
            //ScrollView{
            HStack{ 
                ForEach(colors.indices, id:\.self){breed in
                    ZStack{ 
                        Rectangle()
                            .fill(colors[breed])
                        Rectangle()
                            .opacity(breed == self.breed ? 0.5 : 0)
                    }.frame(width: 50, height: 30)
                    /*.onTapGesture {
                        self.breed = breed
                        if let c = UIColor(colors[breed]).cgColor.components{
                            color = simd_float4(c.map{ Float($0) })
                        }
                    }*/
                    .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
                        .onChanged{ value in
                            self.breed = breed
                            if let c = UIColor(colors[breed]).cgColor.components{
                                color = simd_float4(c.map{ Float($0) })
                            }
                            coord = [Float.random(in: 0...2000),
                                     Float.random(in: 0...2000)]
                            //print(coord)
                            dragging = true
                        }
                        .onEnded{_ in
                            dragging = false
                        })
                }
                ZStack{
                    Text("blob mode")
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(blob ? Color.white : Color.clear)
                }
                .frame(width: 100, height: 30)
                .onTapGesture {
                    blob.toggle()
                    uniforms.setFloat(blob ? 1:0, for: "blob")
                }
                ZStack{
                    Text("pause")
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(play==0 ? Color.white : Color.clear)
                }
                .frame(width: 100, height: 30)
                .onTapGesture {
                    play = play==0 ? 1 : 0
                }
                Button("save") {
                    play = 0
                    save = 1
                }
                Button("load") {
                    play = 0
                    load = 1
                }
            }
            UniformsView(uniforms)
                    .frame(height: 100)
           
            }
       // }
    }
    func saveTexture(device: MTLDevice){
        //save
        let texture = drawTexture.texture!
        let region = MTLRegion(origin: MTLOrigin(),
                               size: MTLSize(width: texture.width,
                                             height: texture.height, depth: 1))
        
        let bytesPerRow = MemoryLayout<SIMD4<UInt8>>.size * texture.width
        let bytesPerImage = bytesPerRow*texture.height
        var texArray = [SIMD4<UInt8>](repeating: SIMD4<UInt8>(repeating: 0), count: bytesPerImage)
        texArray.withUnsafeMutableBytes{ bts in
            texture.getBytes(bts.baseAddress!, 
                             bytesPerRow: bytesPerRow,
                             from: region,
                             mipmapLevel: 0)
        }
        data = Data(bytes: &texArray, count: bytesPerImage)
    }
    func loadTexture(device: MTLDevice){
        //load
        let texture = drawTexture.texture!
        let region = MTLRegion(origin: MTLOrigin(x: 0, y: 0, z: 0),
                               size: MTLSize(width: texture.width,
                                             height: texture.height, depth: 1))
        let bytesPerRow = MemoryLayout<SIMD4<UInt8>>.size * texture.width
        data.withUnsafeBytes{ bts in
            drawTexture.texture!.replace(region: region, mipmapLevel: 0,
                                         withBytes: bts.baseAddress!, bytesPerRow: bytesPerRow)
        }
    }
    func saveBuffer(device: MTLDevice){
        let elementSize = MemoryLayout<Particle>.stride
        let length = elementSize*particlesCount
        bufData = Data(bytes: particlesBuffer.buffer!.contents(), count: length)
    }
    func loadBuffer(device: MTLDevice){
        let elementSize = MemoryLayout<Particle>.stride
        let length = elementSize*particlesCount
        bufData.withUnsafeBytes{ bts in
            particlesBuffer.buffer = device.makeBuffer(bytes: bts.baseAddress!, length: length)
            if let buffer = particlesBuffer.buffer{
                
                particlesBuffer.pointer = buffer.contents().bindMemory(to: Particle.self, capacity: length)
            }
        }
    }
}

func createParticles(_ buffer: MTLBufferContainer<Particle>){
    for idx in 0..<buffer.count!{
        let coord = simd_float2.random(in: -1...1)
        let velo = simd_float2.random(in: -0.00...0.00)
        let color = simd_float4([0.9, 0.9, 1, 1])*Float.random(in: 0.9...1)
        buffer.pointer![idx] = Particle(coord: [coord.x, coord.y,
                                                coord.x-velo.x,
                                                coord.y-velo.y],
                                        size: 0,
                                        color: color, force: [0, 0], breed: -1)// [0, color.y*0.2, color.z+0.5, 1])
    }
}
